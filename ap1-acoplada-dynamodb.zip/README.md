# ap1-acoplada-dynamo

## 🚀 Descripción
Versión acoplada con **DynamoDB + API Gateway + ALB + EC2**.
Cumple los requisitos de la práctica AWS Cloud.

## ⚙️ Despliegue
1. Abre **AWS Academy → CloudFormation**.
2. Create stack → "With new resources".
3. Sube `cloudformation.yaml`.
4. Espera 10 minutos.

## 🌐 Prueba
1. Ve a *Outputs*.
2. Abre la URL `ApiURL` → mostrará tu interfaz CRUD.
